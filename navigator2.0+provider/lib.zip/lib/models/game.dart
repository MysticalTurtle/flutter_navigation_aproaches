class Game {
  String name;
  String description;

  Game(this.name, this.description);
}