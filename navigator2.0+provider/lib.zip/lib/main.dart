import 'package:flutter/material.dart';
import 'package:navigator/screens/all.dart';
import 'package:provider/provider.dart';
import 'controllers/game.dart';
import 'controllers/navigation.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ListenableProvider<NavigationController>(
          create: (_) => NavigationController(),
        ),
      ListenableProvider<GameController>(
        create: (_) => GameController(),
      )
      ],
      child: const NavApp(),
    ),
  );
}

class NavApp extends StatelessWidget {
  const NavApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    NavigationController navigation =
        Provider.of<NavigationController>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Navigator(
        pages: [
          const MaterialPage(
            child: ListScreen(),
          ),
          if (navigation.screenname == '/settings')
          const MaterialPage(child: SettingsScreen()),
          if (navigation.screenname == '/about')
          const MaterialPage(child: AboutScreen()),
        ],
        onPopPage: (route, result) {
          bool popStatus = route.didPop(result);
          if (popStatus) {
            Provider.of<NavigationController>(context, listen: false).changeScreen('/');
          }
          return popStatus;
        },
      ),
    );
  }
}
